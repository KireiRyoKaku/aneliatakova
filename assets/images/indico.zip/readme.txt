Indico is a gothic-antiqua inspired font. It supports Latin and Cyrillic alphabet. 

It is free for Personal and Commercial use.

Pay what you like:
https://teadorovic.gumroad.com/l/fontindico

Appreciate and follow:
https://www.behance.net/teodoratodorovic