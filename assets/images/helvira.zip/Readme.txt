NOTE: This demo font is for PERSONAL USE ONLY! But any donation are very appreciated.
- Paypal account for donation : https://paypal.me/dida21

- Link to purchase full version and commercial license:
https://ahweproject.com/product/helvira/

- If you need an extended license or corporate license, please contact us
ahweproject@gmail.com

Thank you.
