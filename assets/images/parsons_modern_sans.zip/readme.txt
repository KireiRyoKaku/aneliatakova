Parsons Modern Sans aas created as university homework project. The brief was to reinvent an old, well known font by modernizing it and trying to improve its flaws, if any.

Parsons Modern Sans is inspired by the Parsons font - designed for "BB and S" in 1917 by Will Ransom. It was based on the distinctive style of leettering he had been doing for advertisers in that city, and was named for I.R. Parsons, advertising manager of a Chicago department store. It's nearly monotone, but with a hand-lettered quality. It has unusual half-serifa and unique forms to a number of letters. The caps M, N, U and Y have a lowercase design.

Parsons Modern Sans remover the serifs, in order to modernize a bit theoriginal font, and keeps the idea of the unique forms to some letters, as well as the lowercase caps of M, N, U and Y. So far, Parsons Modern Sans comes only in its regular style, and is free, as a contribution to the open-source community.

Follow and subscribe:

https://www.instagram.com/silvashaleva/

https://www.behance.net/silvashaleva

